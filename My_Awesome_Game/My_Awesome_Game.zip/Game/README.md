README:

First practical exercise of the Project I subject.

Create a program that shows a square that can be moved with the direction keys of the keyboard.

By Angel Gonzalez.