Square Game v0.2

Features included in this version: Laser, escape/x buttons and the space that the square can traverse is now limited to the window borders.

By Angel Gonzalez T. 